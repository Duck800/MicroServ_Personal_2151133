<template>
  <div>
    <!-- 路由出口 路由匹配到的组件将渲染在这里 -->
    <router-view></router-view>
  </div>
</template>

<script setup>
// import request from "./utils/request"
// request ({
//   method:"GET",
//   url:"/user/getAdlist"
// }) .then ((res)=>{
//   console.log(res)
// })

</script>

<style>
</style>
